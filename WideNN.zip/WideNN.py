import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, confusion_matrix
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.model_selection import KFold
import time
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns

print("finished imports")

# Define neural network class
class Classifier(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(Classifier, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out = self.fc1(x)
        out = self.relu(out)
        out = self.fc2(out)
        return out


# Load data from CSV file
# data = pd.read_csv('DM_creditcard_2023_sample.csv')
data = pd.read_csv('DM_creditcard_2023.csv')

# Extract features and labels
X = data.drop(columns=['Class_label'])  # Features
y = data['Class_label']  # Labels

# Encode labels
label_encoder = LabelEncoder()
y = label_encoder.fit_transform(y)

# Convert to PyTorch tensors
X = torch.tensor(X.values.astype(np.float32))
y = torch.tensor(y)

# Define cross-validation splits
kf = KFold(n_splits=5, shuffle=True, random_state=42)

# Define hyperparameters
input_size = X.shape[1]
output_size = len(np.unique(y))
hidden_sizes = [8, 16, 32, 96, 128, 256]
# hidden_sizes = [8]

# Perform cross-validation
for hidden_size in hidden_sizes:

    timestamp = time.time()
    dt = datetime.fromtimestamp(timestamp)
    print()
    print("Begin Train/Test for", hidden_size, "hidden nodes at time:", dt)

    accuracies = []
    confusion_matrices = []
    for train_index, test_index in kf.split(X):
        # Split data into training and testing sets
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]

        # Create model, optimizer, and loss function
        model = Classifier(input_size, hidden_size, output_size)
        criterion = nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

        # Create data loaders
        train_dataset = TensorDataset(X_train, y_train)
        train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)

        # Train the model
        num_epochs = 10
        for epoch in range(num_epochs):
            for inputs, labels in train_loader:
                optimizer.zero_grad()
                outputs = model(inputs)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

        # Evaluate the model
        with torch.no_grad():
            model.eval()
            outputs = model(X_test)
            _, predicted = torch.max(outputs, 1)
            accuracy = accuracy_score(y_test.numpy(), predicted.numpy())
            accuracies.append(accuracy)
            confusion_matrices.append(confusion_matrix(y_test.numpy(), predicted.numpy()))
            model.train()

    # Calculate average accuracy for current hidden size
    avg_accuracy = np.mean(accuracies)
    avg_confusion_matrix = np.mean(confusion_matrices, axis=0)
    print(f'Hidden Size: {hidden_size}, Average Accuracy: {avg_accuracy:.4f}')
    print(f'Average Confusion Matrix:\n{avg_confusion_matrix}')
    print("(top left: true negative, lower left: false negative",
          "\ntop right: false positive, bottom right: true positive)")

# Plot for final graph to give perspective
plt.figure(figsize=(8, 6))
sns.heatmap(avg_confusion_matrix, annot=True, fmt='.5g', cmap='Blues', xticklabels=label_encoder.classes_, yticklabels=label_encoder.classes_)
plt.title('Confusion Matrix')
plt.xlabel('Predicted Label')
plt.ylabel('True Label')
plt.show()

timestamp = time.time()
dt = datetime.fromtimestamp(timestamp)
print()
print("Finished all training at:", dt)
